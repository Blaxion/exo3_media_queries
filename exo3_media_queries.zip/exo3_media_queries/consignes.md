# Exercice 3 -> Media Queries

## - Pour des écrans plus grands que 1024px un carré qui fait 1/3 de l'écran en largeur et une couleur de fond blue

## - Pour des écrans entre 600px et 1024px un carré qui fait 2/3 de l'écran en largeur et une couleur de fond rouge

## - Pour des écrans entre 320px et 600px un carré qui fait 3/3 de l'écran en largeur et une couleur de fond orange

